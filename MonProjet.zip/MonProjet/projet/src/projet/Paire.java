package projet;

public class Paire {
	int volume;
    String type;
    public Paire(int volume,String type){
        this.volume=volume;
        this.type=type;
    }
}
