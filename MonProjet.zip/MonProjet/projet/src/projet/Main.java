package projet;

public class Main {

	public static void main(String[] args) {
		
		Menu.lancerMenu();
		
		
//		Entrepot e = new Entrepot(10,10,2000);
//		Chefstock cs = new Chefstock("Chef", "Stock");
//		Chefbrico cb = new Chefbrico("Mac", "Gyver");
//		Ouvrier o = new Ouvrier("Ou", "Vrier", "Cuisine");
//		LotPiece lp = new LotPiece(1, "Planche", 3, 3);
//		LotPiece lp2 = new LotPiece(1, "Clou", 3, 3);
//		e.recruterchefstock(cs);
//		e.recruterchefbrico(cb);
//		e.recruterouvrier(o);
//		System.out.println(e.ajoutlot(lp));
//		System.out.println(e.ajoutlot(lp2));
//		Meuble m = new Meuble("Lit", "Cuisine", 6);
//		System.out.println(e.montermeuble(m));
////		for(int i = 0; i<e.ligne.length;i++) {
////			for(int j = 0; j<e.ligne[i].place.length; j++) {
////				System.out.println(e.ligne[i].place[j]);
////			}
////		}
//		

//		for(int i =0; i<e.chef_equipe.size();i++) {
//			System.out.println(e.chef_equipe.get(i).nom);
//			for(int j = 0; j<e.chef_equipe.get(i).liste_ouv.length;j++) {
//				if(e.chef_equipe.get(i).liste_ouv[j]!=null)
//					System.out.println(e.chef_equipe.get(i).liste_ouv[j].prenom);
//				else
//					System.out.println(e.chef_equipe.get(i).liste_ouv[j]);
//			}
//		}
		
		
	}

}
