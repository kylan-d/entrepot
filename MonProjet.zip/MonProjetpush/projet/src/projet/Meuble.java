package projet;
import java.util.ArrayList;

public class Meuble {
	ArrayList<Paire> liste_lot_piece;
    String piece;
    int duree;
    double prix;
    String nom;
    
    public Meuble( String nom,String piece, int duree){
        this.nom=nom;
        this.piece=piece;
        this.duree=duree;
        liste_lot_piece=new ArrayList<Paire>();

    }
    
    public void addcompo(Paire p){
        liste_lot_piece.add(p);
    }
    
    public double calculerPrix(LotPiece lp) {
    	double resultat = 0;
		for(int k = 0; k<liste_lot_piece.size(); k++) {
			if(lp.piece.nom.equals(liste_lot_piece.get(k).type)) {
				resultat += (lp.prix * liste_lot_piece.get(k).volume);
			}
		}

    	prix = resultat;
    	return resultat;
    }
    
    
}
