package projet;
import java.util.ArrayList;

/**
 * Un Meuble est un objet qui permet de le stockage de differents objets.
 * @author Abdesamad - Kylan
 * @version 1.0
 */
public class Meuble {
    // liste_lot_piece : correspond aux a� la liste des LotPiece necessaire a� la construction du meuble.
    private ArrayList<Paire> liste_lot_piece;
    //  piece : correspond a� l'endroit (maison, appartement,...) dans lequel le meuble va etre entreposer.
    private String piece;
    // duree : correspond au temps de construction du meuble.
    private int duree;
    // duree : correspond au prix du meuble (somme de tous les LotPiece)
    private double prix;
    // nom : correspond au nom du Meuble.
    private String nom;
    // id : correspond a� l'identifiant du meuble.
    int id;
    // i : est un nombre qui va s'incrementer a� chaque fois qu'on cree une commande de meuble et cette valeur va etre associe a� l'identifiant du meuble
    static int i = 1;

    /**
     * Constructeur de la classe Meuble
     * @param nom correspond au nom du {@link Meuble}.
     * @param piece correspond a� l'endroit dans lequel le {@link Meuble} va etre placer.
     * @param duree correspond a� la duree de construction du {@link Meuble}.
     */
    public Meuble( String nom,String piece, int duree){
        this.setNom(nom);
        this.setPiece(piece);
        this.setDuree(duree);
        this.setId(i++);
        this.setListe_lot_piece(new ArrayList<Paire>());

    }

    /**
     * Fonction qui va ajouter une {@link Paire} au Meuble.
     * @param p correspond a� une {@link Paire} (nom du {@link LotPiece} et volume). Cette Paire va indiquer quelles sont les elements et la quantite necessaire au montage du Meuble.
     */
    public void addcompo(Paire p){
        liste_lot_piece.add(p);
    }

    /**
     * Fonction qui calcule le prix du Meuble.
     * @param lp correspond a� un {@link LotPiece}.
     * @return retourne le prix du Meuble.
     */
    public double calculerPrix(LotPiece lp) {
        double resultat = 0;
        for(int k = 0; k<liste_lot_piece.size(); k++) {
            if(lp.getPiece().getNom().equals(liste_lot_piece.get(k).getType())) {
                resultat += (lp.getPrix() * liste_lot_piece.get(k).getVolume());
            }
        }
        prix = resultat;
        return resultat;
    }

    /**
     * Fonction qui recupere la liste des paire du Meuble. (Getter)
     * @return return une ArrayList de paire du Meuble.
     */
    public ArrayList<Paire> getListe_lot_piece() {
        return liste_lot_piece;
    }

    /**
     * Fonction qui permet de modifier l'ArrayList de paire du Meuble. (Setter)
     * @param liste_lot_piece correspond a� une ArrayList de Paire.
     */
    public void setListe_lot_piece(ArrayList<Paire> liste_lot_piece) {
        this.liste_lot_piece = liste_lot_piece;
    }

    /**
     * Fonction qui permet de recuperer la piece associer au Meuble. (Getter)
     * @return return la piece associer au Meuble.
     */
    public String getPiece() {
        return piece;
    }

    /**
     * Fonction qui permet de modifier la piece associer au Meuble. (Setter)
     * @param piece correspond a� la piece que l'on va associer au Meuble.
     */
    public void setPiece(String piece) {
        this.piece = piece;
    }

    /**
     * Fonction qui permet de recuperer la duree de construction du Meuble. (Getter)
     * @return return la duree de construction du Meuble.
     */
    public int getDuree() {
        return duree;
    }

    /**
     * Fonction qui permet de modifier la duree de construction du Meuble. (Setter)
     * @param duree correspond a� la duree de construction que l'on va associer au Meuble.
     */
    public void setDuree(int duree) {
        this.duree = duree;
    }

    /**
     * Fonction qui permet de recuperer le prix du Meuble. (Getter)
     * @return return le prix du Meuble.
     */
    public double getPrix() {
        return prix;
    }

    /**
     * Fonction qui permet de modifier la valeur du prix de Meuble. (Setter)
     * @param prix correspond au prix que l'on va associer au Meuble.
     */
    public void setPrix(double prix) {
        this.prix = prix;
    }

    /**
     * Fonction qui permet de recuperer le nom du Meuble. (Getter)
     * @return return le nom du Meuble.
     */
    public String getNom() {
        return nom;
    }

    /**
     * Fonction qui permet de modifier la valeur du nom du Meuble. (Setter)
     * @param nom correspond au nom du Meuble.
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Fonction qui recupere l'identifiant du meuble. (Getter)
     * @return return l'identifiant du meuble.
     */
    public int getId() {
        return id;
    }

    /**
     * Fonction qui modifie la valeur de l'identifiant du meuble. (Setter)
     * @param id correspond a� l'identifiant que l'on va associer au meuble.
     */
    public void setId(int id) {
        this.id = id;
    }






}

