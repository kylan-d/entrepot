package projet;


/**
 * Une Reservation correspond � un meuble mis en attente pour cause : manque de personnel ou de materiaux.
 * @author Abdesamad - Kylan
 * @version 1.0
 */
public class Reservation {
    private int idlot;
    private int volumelot;
    private int idmeuble;
    private double prix;

    /**
     * Constructeur de la classe Paire.
     * @param volumelot correspond a� la quantite de Piece necessaire a� la constuction du {@link Meuble}.
     * @param idlot correspond a l'id de la Piece necessaire a� la construction du {@link Meuble}.
     * @param idmeuble correspond a l'id du {@link Meuble} construit.
     * @param prix correspond au prix de la Piece necessaire a� la construction du {@link Meuble}.
     */
    public Reservation(int idlot,int volumelot,int idmeuble,double prix){
        this.volumelot=volumelot;
        this.idlot=idlot;
        this.idmeuble=idmeuble;
        this.prix=prix;
    }
    /**
     * Fonction qui recupere l'identifiant du lot. (Getter)
     * @return return l'identifiant du lot.
     */
    public int getIdlot(){
        return idlot;
    }
    /**
     * Fonction qui modifie la valeur de l'identifiant du lot. (Setter)
     * @param newid correspond a� l'identifiant que l'on va associer au lot.
     */
    public void setIdlot(int newid){
        idlot=newid;
    }
    /**
     * Getter qui r�cup�re l'id du meuble
     * @return return l'id du meuble.
     */
    public int getIdmeuble(){
        return idmeuble;
    }
    /**
     * Setter qui modifier la valeur de l'id du meuble
     * @param newid correspond � la valeur qui va remplacer l'ancienne valeur d'id. 
     */
    public void setIdmeuble(int newid){
        idmeuble=newid;
    }
    /**
     * Fonction qui permet de recuperer le volume de la Piece reserve. (Getter)
     * @return Fonction qui permet de recuperer le volume de la Piece.
     */
    public int getVolumelot(){
        return volumelot;
    }
    /**
     * Fonction qui permet de modifier la valeur du volume de la Piece. (Setter)
     * @param newvol correspond au volume pris que l'on va associer a� la Piece.
     */
    public void setVolumelot(int newvol){
        volumelot=newvol;
    }
    /**
     * Fonction qui permet de recuperer le prix de la Piece. (Getter)
     * @return Fonction qui permet de recuperer le prix de la Piece.
     */
    public double getPrix(){
        return prix;
    }

    /**
     * Fonction qui permet de modifier la valeur prix de la Piece. (Setter)
     * @param newprix correspond au prix que l'on va associer a� la Piece.
     */
    public void setPrix(double newprix){
        prix=newprix;
    }
}
