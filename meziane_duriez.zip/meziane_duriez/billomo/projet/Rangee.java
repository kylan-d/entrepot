package projet;

/**
 * Une Rangee correspond a� un emplacement dans l'{@link Entrepot} qui permet le stockage de {@link LotPiece}.
 * @author Abdesamad - Kylan
 * @version 1.0
 */
public class Rangee {
    // taille : correspond a� la taille de la Rangee.
    private int taille;
    // taille_restante : correspond a� la taille restante dans la Rangee.
    private int taille_restante;
    // place[] : correspond au contenue present dans la Rangee.
    private LotPiece place[];
    /**
     * Constructeur de la classe Rangee.
     * @param n correspond a� la taille de la Rangee.
     */
    public Rangee(int n){
        taille=n;
        taille_restante=n;
        place= new LotPiece[n];
    }

    /**
     * Fonction qui recupere la taille de la Rangee. (Getter)
     * @return return la taille de la Rangee.
     */
    public int getTaille() {
        return taille;
    }

    /**
     * Fonction qui permet de modifier la taille de la Rangee. (Setter)
     * @param taille correspond a� la taille que l'on va associer a� la Rangee.
     */
    public void setTaille(int taille) {
        this.taille = taille;
    }

    /**
     * Fonction qui return la taille restante de la Rangee. (Getter)
     * @return return la taille restante de la Rangee.
     */
    public int getTaille_restante() {
        return taille_restante;
    }

    /**
     * Fonction qui permet de modifier la taille restante de la Rangee. (Setter)
     * @param taille_restante correspond a� la taille restante que l'on va associer a� la Rangee.
     */
    public void setTaille_restante(int taille_restante) {
        this.taille_restante = taille_restante;
    }

    /**
     * Fonction qui va recupere le contenu de la Rangee. (Getter)
     * @return return un tableau qui contient le contenu de la Rangee.
     */
    public LotPiece[] getPlace() {
        return place;
    }

    /**
     * Fonction qui va modifier le contenu de la Rangee.
     * @param place correspond au contenu que l'on va associer a� la Rangee.
     */
    public void setPlace(LotPiece[] place) {
        this.place = place;
    }

    /**
     * Fonction qui permet de recupere un certain {@link LotPiece} (Getter)
     * @param k correspond au keme {@link LotPiece} que l'on recherche.
     * @return return un {@link LotPiece}
     */
    public LotPiece getPlace(int k) {
        LotPiece resultat = null;
        for(int i = 0; i<this.place.length; i++) {
            if(i == k) {
                resultat = this.place[i];
            }
        }
        return resultat;
    }

    /**
     * Fonction qui modifier un {@link LotPiece} (Setter)
     * @param k correspond a� l'emplacement k de la {@link Rangee}
     * @param lp correspond au {@link LotPiece} que l'on souhaite ajoutee.
     */
    public void setPlace(int k, LotPiece lp) {
        for(int i = 0; i<this.getPlace().length; i++) {
            if(i == k ) {
                this.place[k] = lp;
            }
        }
    }



}

